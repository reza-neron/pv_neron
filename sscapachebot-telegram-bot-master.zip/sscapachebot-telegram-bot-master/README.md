# sscapachebot-telegram-bot

required php modules :

php5-curl , php5-apc
